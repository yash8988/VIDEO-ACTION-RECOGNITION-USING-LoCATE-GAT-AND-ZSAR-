#!/bin/bash
cd /workspace/udit/arijit/sandipan/zsar_divyam/own_zsar/baseline

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet0/' --split_index=0 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet1/' --split_index=1 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet2/' --split_index=2 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet3/' --split_index=3 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet4/' --split_index=4 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet5/' --split_index=5 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet6/' --split_index=6 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet7/' --split_index=7 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet8/' --split_index=8 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4

# python3 main.py --action=train --dataset=activitynet --network=clip_transformer --semantic=clip --image_size=224 --save_path='../../log/log_transformer_anet9/' --split_index=9 --n_epochs=16 --lr=2e-7 --early_stop_thresh=4
